#!/bin/sh - 49,141 47,140 45,139 43,138
echo 138 /sys/class/gpio/export
echo in > /sys/class/gpio/gpio138/direction 
echo 139 /sys/class/gpio/export
echo in > /sys/class/gpio/gpio139/direction 
echo 140 /sys/class/gpio/export
echo out > /sys/class/gpio/gpio140/direction 
echo 141 /sys/class/gpio/export
echo out > /sys/class/gpio/gpio141/direction 
